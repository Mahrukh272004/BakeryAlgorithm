//Mahrukh Wahidi
//21i-1765
#include <iostream>
#include <pthread.h>
#include <atomic>
#include <limits.h>
#include <unistd.h>

using namespace std;

class Ticket {
public:
    atomic<bool> inCritical;  // checks if a thread is in the critical section
    int ticket;
    int QueuePos;
    bool executed;

    Ticket() {
        inCritical = false;
        ticket = 0;
        QueuePos = 0;
        executed = false;
    }
};

class BakeryLock {
public:
    int numThreads;           // Number of threads
    Ticket* tickets;         
    atomic<int> nextTicket;    //atomic variabe for next ticket number assignment

    BakeryLock(int n) {
        numThreads = n;
        tickets = new Ticket[n];
        nextTicket = 1;  // Start with ticket number 1

        for (int i = 0; i < n; ++i) {
            tickets[i].QueuePos = 0;
            tickets[i].executed = false;
        }
    }

    // Acquires method
    void lock(int i) {
        tickets[i].executed = true;

        // maximum ticket number
        int maxTicket = INT_MIN;
        for (int j = 0; j < numThreads; j++) {
            int t = tickets[j].ticket;
            if (t > maxTicket)
                maxTicket = t;
        }


        tickets[i].ticket = maxTicket + 1;
        tickets[i].QueuePos = maxTicket + 1;
        tickets[i].executed = false;


        for (int j = 0; j < numThreads; j++) {
            while (tickets[j].executed);
            while ((tickets[j].QueuePos != 0) && ((tickets[i].QueuePos > tickets[j].QueuePos) || ((tickets[i].QueuePos == tickets[j].QueuePos) && (i > j))));
        }
    }

    // Releases
    void unlock(int i) {
        tickets[i].QueuePos = 0;
    }
};

int num = 0;
BakeryLock lock(8);  // Create a BakeryLock instance with 8 threads

void *ThreadFunc(void *p) {
    int i = *(int*)p;

    lock.lock(i);
    cout << "Thread " << i + 1 << " ticket number " << lock.tickets[i].ticket << endl;
    cout << "Thread " << i + 1 << " locked the critical section" << endl;
    num++;
    lock.unlock(i);
    cout << "Thread " << i + 1 << " unlocked the critical section" << endl << endl;
    return NULL;
}

int main() {
    pthread_t thread[8];
    int ThreadNum[8] = {0, 1, 2, 3, 4, 5, 6, 7};

    // Create 8 threads
    for (int i = 0; i < 8; i++) {
        sleep(1);
        pthread_create(&thread[i], NULL, &ThreadFunc, (void*)&ThreadNum[i]);
    }

    // Join threads
    for (int i = 0; i < 8; i++)
        pthread_join(thread[i], NULL);
        
 

    return 0;
}
